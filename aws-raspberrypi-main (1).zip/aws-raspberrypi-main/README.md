# aws-raspberrypi
Lets Learn how to send data from Raspberry Pi4 to AWS IoT Core using MQTT Protocol. 
